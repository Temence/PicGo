#! /bin/bash

MASTER_IP=`cat /data/redis/sentinel/master.txt`
LOCAL_IP='x.x.x.x'  #本机ip
VIP='10.1.17.37'  
NETMASK='20'
INTERFACE='eth0'
if [ ${MASTER_IP} = ${LOCAL_IP} ];then   
    /sbin/ip  addr  add ${VIP}/${NETMASK}  dev ${INTERFACE}  #将VIP绑定到该服务器上
    /sbin/arping -q -c 3 -U ${VIP} -I ${INTERFACE}
    exit 0
else 
   /sbin/ip  addr del  ${VIP}/${NETMASK}  dev ${INTERFACE}   #将VIP从该服务器上删除
   exit 0
fi