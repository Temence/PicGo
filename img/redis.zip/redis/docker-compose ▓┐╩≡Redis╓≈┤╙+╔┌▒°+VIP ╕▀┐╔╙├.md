# docker-compose 部署Redis主从+哨兵+VIP 高可用

[toc]

## 1. 系统架构

| 主机名      | 主机IP     | 角色                                | 备注                                            |
| ----------- | ---------- | ----------------------------------- | ----------------------------------------------- |
| redis-node1 | 10.1.17.38 | 初始化为Master:6379、Sentinel:26379 | 关闭防火墙、selinux、安装docker、docker-compose |
| redis-node2 | 10.1.18.86 | 初始化为slave:6379、Sentinel:26379  | 关闭防火墙、selinux、安装docker、docker-compose |
| redis-node3 | 10.1.19.58 | 初始化为slave:6379、Sentinel:26379  | 关闭防火墙、selinux、安装docker、docker-compose |

![](https://cdn.jsdelivr.net/gh/Temence/PicGo/img/20220622151818.png)





## 2. docker-compose文件介绍

```
以下文件及目录需要存放在/root/redis/

|-- init.sh  #当master、slave、sentinel部署完成后，关闭master角色后，在每个节点上运行该脚本，生成初始化VIP、并加入系统定时任务
|-- monitor_master.sh    #用于监控最新MasterIP，并将VIP切换到最新的Master节点
|-- master  初始化部署Master使用目录
|   |-- docker-compose.yml
|   |-- init.sh  部署Master只需运行该脚本
|   |-- redis.conf
|-- sentinel 初始化部署sentinel使用目录
|   |-- docker-compose.yml
|   |-- init.sh  部署Master只需运行该脚本
|   |-- notify_master.sh
|   `-- sentinel.conf
|-- slave 初始化部署slave使用目录
|   |-- docker-compose.yml
|   |-- init.sh   部署Master只需运行该脚本
|   |-- redis.conf

```

## 3. 安装Master

```
[root@redis-node1 master]# pwd
/root/redis/master
[root@redis-node1 master]# tree
.
├── docker-compose.yml
├── init.sh
└── redis.conf
[root@redis-node1 master]# sh -x init.sh

检查容器和配置文件映射情况
[root@redis-node1 master]# docker ps | grep master
8a9635240457        redis:7.0.2         "docker-entrypoint.s…"   3 hours ago         Up 3 hours          0.0.0.0:6379->6379/tcp   redis-master
[root@redis-node1 master]# tree /data/redis/master/
/data/redis/master/
├── conf
│   └── redis.conf
├── data
│   ├── appendonlydir
│   │   ├── appendonly.aof.2.base.rdb
│   │   ├── appendonly.aof.2.incr.aof
│   │   └── appendonly.aof.manifest
│   └── dump.rdb
└── logs
    └── redis.log
```

## 4.安装slave

```
[root@redis-node2 slave]# pwd
/root/redis/slave
[root@redis-node2 slave]# tree
.
├── docker-compose.yml
├── init.sh
└── redis.conf
[root@redis-node2 slave]# sh -x init.sh

检查容器和配置文件映射情况
[root@redis-node2 slave]# docker ps | grep slave
22639bc5a745        redis:7.0.2         "docker-entrypoint.s…"   4 hours ago         Up 54 minutes       0.0.0.0:6379->6379/tcp   redis-slave
[root@redis-node2 slave]# tree /data/redis/slave/
/data/redis/slave/
├── conf
│   └── redis.conf
├── data
│   ├── appendonlydir
│   │   ├── appendonly.aof.4.base.rdb
│   │   ├── appendonly.aof.4.incr.aof
│   │   └── appendonly.aof.manifest
│   └── dump.rdb
└── logs
    └── redis.log

另外一台slave 同样使用以上方法安装salve
```

## 5. 安装sentinel

```
[root@redis-node2 sentinel]# pwd
/root/redis/sentinel
[root@redis-node2 sentinel]# tree
.
├── docker-compose.yml
├── init.sh
├── notify_master.sh
└── sentinel.conf
[root@redis-node2 sentinel]# sh -x init.sh

检查容器和配置文件映射情况
[root@redis-node2 sentinel]# docker ps | grep sentinel
319211a0cc7e        redis:7.0.2         "docker-entrypoint.s…"   4 hours ago         Up About an hour                             redis-sentinel
[root@redis-node2 sentinel]# tree /data/redis/sentinel/
/data/redis/sentinel/
├── master.txt
├── notify_master.sh
└── sentinel.conf

另外两台sentinel 同样使用以上方法安装sentinel
```

## 6. 检查主从状态

```
[root@redis-node1 ~]# docker exec -it redis-master redis-cli -p 6379 -a redispwd info Replication
Warning: Using a password with '-a' or '-u' option on the command line interface may not be safe.
# Replication
role:master
connected_slaves:2
slave0:ip=10.1.19.58,port=6379,state=online,offset=2576439,lag=1
slave1:ip=10.1.18.86,port=6379,state=online,offset=2576439,lag=1
master_failover_state:no-failover
master_replid:c46136cd99fba5627ef74e6f1063d3f47911ed3f
master_replid2:643eb0fe85e079aae815280db4d11a24b35ebe5a
master_repl_offset:2576574
second_repl_offset:1798497
repl_backlog_active:1
repl_backlog_size:1048576
repl_backlog_first_byte_offset:1752657
repl_backlog_histlen:823918
```

## 7.初始化VIP并更新系统定时任务

```
关闭master 容器   #必须操作，需要让哨兵检测到新的Maser IP
三台主机操作以下：
[root@redis-node1 redis]# pwd
/root/redis
[root@redis-node1 redis]# ll
total 8
-rw-rw-rw- 1 root root 248 Jun 22 11:37 init.sh
drwxr-xr-x 2 root root  65 Jun 22 11:29 master
-rw-rw-rw- 1 root root 452 Jun 22 11:37 monitor_master.sh
drwxr-xr-x 2 root root  92 Jun 22 11:31 sentinel

[root@redis-node1 redis]# sh -x init.sh 

检查以下：
[root@redis-node1 redis]# crontab -l
*/1 * * * * /usr/bin/sh /root/redis/monitor_master.sh

```

