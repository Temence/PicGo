#! /bin/bash

mkdir -p /data/redis/slave/conf
mkdir -p /data/redis/slave/data
mkdir -p /data/redis/slave/logs
cp ./redis.conf /data/redis/slave/conf
chmod -R 777 /data/redis/slave
docker-compose up -d
