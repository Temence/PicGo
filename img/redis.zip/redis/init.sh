#! /bin/bash

HOSTIP=`ip a show dev eth0 |grep -w inet | grep brd |awk '{print $2}'|awk -F '/' '{print $1}'`
sed -i "s/x.x.x.x/$HOSTIP/g" monitor_master.sh

echo "*/1 * * * * /usr/bin/sh /root/redis/monitor_master.sh " >>  /var/spool/cron/root