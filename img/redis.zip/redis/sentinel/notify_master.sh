#!/bin/bash
MASTER_IP=$6  #第六个参数是新主redis的ip地址
echo $MASTER_IP > /usr/local/etc/redis/master.txt
