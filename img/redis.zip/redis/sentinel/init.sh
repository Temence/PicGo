#! /bin/bash

HOSTIP=`ip a show dev eth0 |grep -w inet | grep brd |awk '{print $2}'|awk -F '/' '{print $1}'`
sed -i "s/x.x.x.x/$HOSTIP/g" ./notify_master.sh
mkdir -p /data/redis/sentinel
cp ./sentinel.conf /data/redis/sentinel
cp ./notify_master.sh /data/redis/sentinel
chmod -R 777 /data/redis/

docker-compose up -d
