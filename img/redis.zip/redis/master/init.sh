#! /bin/bash

mkdir -p /data/redis/master/conf
mkdir -p /data/redis/master/data
mkdir -p /data/redis/master/logs
cp ./redis.conf /data/redis/master/conf
chmod -R 777 /data/redis/master
docker-compose up -d
